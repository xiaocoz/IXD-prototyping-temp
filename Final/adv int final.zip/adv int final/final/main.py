import js as p5
from js import document

data_string = None
data_list = None
sensor_val = None
circle_size = 20

def setup():
    p5.createCanvas(300, 300)
    # change mode to draw rectangles from center:
    p5.rectMode(p5.CENTER)
    # change mode to draw images from center:
    p5.imageMode(p5.CENTER)
    # change stroke cap to square:
    p5.strokeCap(p5.SQUARE)

def draw():
    global data_string, data_list, circle_size
    global sensor_val

    data_string = document.getElementById("data").innerText
    data_list = data_string.split(',')

    sensor_val = int(data_list[0])

    p5.background(255)
    p5.fill(100, 100, 255)

    # 圆的大小由 sensor_val 控制
    circle_size = map_value(sensor_val, 9200, 10000, 10, 100)
    p5.ellipse(150, 150, circle_size, circle_size) 

def map_value(value, in_min, in_max, out_min, out_max):
    return (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min
