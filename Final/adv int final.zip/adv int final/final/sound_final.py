import os, sys, io
import M5
from M5 import *
from hardware import *
from umqtt import *
import time

mqtt_client = None
user_name = 'Erinnes'

rgb = None
analog_pin = None
sample_interval = 0.01  # Sampling interval in seconds
samples_per_50ms = 5  # Number of samples per 0.05 seconds
current_color = (0, 0, 0)  # Initialize the current color

mqtt_timer = 0

mic_timer = 0
mic_sample_counter = 0
mic_total_volume = 0

target_color = (0, 0, 0)

def setup():
    global rgb, analog_pin
    global mqtt_client
    M5.begin()

    # Initialize RGB LED (assuming using pin G7 and 10 LEDs):
    rgb = RGB(io=7, n=90, type="SK6812")

    # Initialize an analog pin for input:
    analog_pin = ADC(Pin(1), atten=ADC.ATTN_11DB)
    
    mqtt_client = MQTTClient(
      'testclient',
      'io.adafruit.com',
      port=1883, 
      user=user_name,
      password='aio_wiar21SGyFlWzl23P2hKE10oNtbF',
      keepalive=0
      )
    mqtt_client.connect(clean_session=True)

def loop():
    global mqtt_client
    global rgb, analog_pin, current_color
    global mqtt_timer, mic_timer
    global mic_sample_counter, mic_total_volume
    global target_color
    
    M5.update()
    
    #average_value = get_average_volume()
    # update volume samples every 50ms:
    if(time.ticks_ms() > mic_timer + 50):
        # add 5 volume samples to add together:
        if(mic_sample_counter < 5):
            mic_total_volume += analog_pin.read()
            # incrememnt counter:
            mic_sample_counter += 1
        # after 5 samples print total volume:
        else:
            print('mic_total_volume =', mic_total_volume)
            # Map the average volume to a color between red and blue:
            target_color = map_volume_to_color(mic_total_volume, 9500, 10000)
            #if mic_total_volume <= 1800:
                #print('loud..')
            fade_to_color(current_color, target_color)
            if(time.ticks_ms() > mqtt_timer + 3000):
                print('publish mqtt data..')
                #mqtt_client.publish(user_name+'/feeds/sound', str(average_value), qos=0)
                mqtt_client.publish(user_name+'/feeds/sound', str(mic_total_volume), qos=0)
                # update timer:
                mqtt_timer = time.ticks_ms()
            # reset volume and counter:
            mic_sample_counter = 0
            mic_total_volume = 0
            
        # update microphone timer:
        mic_timer = time.ticks_ms()

    
    current_color = target_color
    #print(average_value)
    # publish data every 3 seconds:
    
    
    #if average_value <= 1800:
    #if mic_total_volume <= 1800:
    #  print('loud..')
      #mqtt_client.publish(user_name+'/feeds/sound', 'loud..', qos=0)
    

    #time.sleep(0.05)  # Update color at a rate of once per 0.05 second
    

def get_average_volume():
    total_value = 0
    for _ in range(samples_per_50ms):
        total_value += analog_pin.read()
        time.sleep(sample_interval)
    return total_value // samples_per_50ms

def map_volume_to_color(value, min_value, max_value):
    # Map the value to a range between 0 and 1
    normalized = (value - min_value) / (max_value - min_value)
    normalized = max(0, min(normalized, 1))  # Clamp between 0 and 1

    # Map the normalized value to a color
    r = int((1 - normalized) * 255)
    b = int(normalized * 255)
    return (r, 0, b)


def fade_to_color(current_color, target_color, steps=50, delay=0.005):
    for step in range(1, steps + 1):
        r = int(current_color[0] + (target_color[0] - current_color[0]) * step / steps)
        g = int(current_color[1] + (target_color[1] - current_color[1]) * step / steps)
        b = int(current_color[2] + (target_color[2] - current_color[2]) * step / steps)
        rgb.fill_color(get_color(r, g, b))
        time.sleep(delay)

def get_color(r, g, b):
    # Convert separate r, g, b values to one rgb_color value:
    rgb_color = (r << 16) | (g << 8) | b
    return rgb_color

if __name__ == '__main__':
    try:
        setup()
        while True:
            loop()
    except (Exception, KeyboardInterrupt) as e:
        try:
            from utility import print_error_msg
            print_error_msg(e)
        except ImportError:
            print("please update to latest firmware")

